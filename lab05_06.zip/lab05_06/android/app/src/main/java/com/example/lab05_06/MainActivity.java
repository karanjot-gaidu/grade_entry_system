package com.example.lab05_06;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
